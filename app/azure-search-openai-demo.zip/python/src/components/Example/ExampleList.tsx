import { Example } from "./Example";

import styles from "./Example.module.css";

export type ExampleModel = {
    text: string;
    value: string;
};

const EXAMPLES: ExampleModel[] = [
    {
        text: "Quero contratar o seguro agora. Como eu devo fazer?",
        value: "Quero contratar o seguro agora. Como eu devo fazer?"
    },
    { text: "Como eu faço pra acionar o seguro em caso de sinistro?", value: "Como eu faço pra acionar o seguro em caso de sinistro?" },
    { text: "Qual o telefone da assistência 24 Horas?", value: "Qual o telefone da assistência 24 Horas?" }
];

interface Props {
    onExampleClicked: (value: string) => void;
}

export const ExampleList = ({ onExampleClicked }: Props) => {
    return (
        <ul className={styles.examplesNavList}>
            {EXAMPLES.map((x, i) => (
                <li key={i}>
                    <Example text={x.text} value={x.value} onClick={onExampleClicked} />
                </li>
            ))}
        </ul>
    );
};
