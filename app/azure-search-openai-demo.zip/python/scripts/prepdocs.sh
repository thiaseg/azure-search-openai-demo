 #!/bin/sh

echo ""
echo "Loading azd .env file from current environment"
echo ""

while IFS='=' read -r key value; do
    value=$(echo "$value" | sed 's/^"//' | sed 's/"$//')
    export "$key=$value"
done <<EOF
$(azd env get-values)
EOF

echo 'Creating python virtual environment "scripts/.venv"'
python -m venv scripts/.venv

echo 'Installing dependencies from "requirements.txt" into virtual environment'
./scripts/.venv/bin/python -m pip install -r scripts/requirements.txt

echo 'Running "prepdocs.py"'
./scripts/.venv/bin/python ./scripts/prepdocs.py './data/*' --storageaccount "st2hyfr4d3p46b6" --container "containerhttps://st2hyfr4d3p46b6.blob.core.windows.net/content" --searchservice "gptkb-2hyfr4d3p46b6" --index "" --formrecognizerservice "cog-fr-2hyfr4d3p46b6" --tenantid "53f52f29-c363-41a4-8888-ea6e6e531c2e" -v


srttenantid = "53f52f29-c363-41a4-8888-ea6e6e531c2e"
strsearchkey="gptkb-2hyfr4d3p46b6"
strformrecognizerservice= "cog-fr-2hyfr4d3p46b6"
strstoragekey = "st2hyfr4d3p46b6"
strcontainer= "https://st2hyfr4d3p46b6.blob.core.windows.net/content"

./scripts/prepdocs.py './data/*' --storageaccount "st2hyfr4d3p46b6" --container "https://st2hyfr4d3p46b6.blob.core.windows.net/content" --searchservice "gptkb-2hyfr4d3p46b6" --formrecognizerservice "cog-fr-2hyfr4d3p46b6" --tenantid "53f52f29-c363-41a4-8888-ea6e6e531c2e" -v
./scripts/prepdocs.py './data/*' --storageaccount "st2hyfr4d3p46b6" --container "content" --searchservice "gptkb-2hyfr4d3p46b6" --index "myindex" --formrecognizerservice "cog-fr-2hyfr4d3p46b6" --tenantid "53f52f29-c363-41a4-8888-ea6e6e531c2e" -v


indexchatgptbv
indexchatgptbv1