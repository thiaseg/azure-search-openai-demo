from datetime import datetime
import openai 
from azure.search.documents import SearchClient
from azure.search.documents.models import QueryType
from chatreadretrieveread import ChatReadRetrieveReadApproach
#from text import nonewlines
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient
import logging
openai.api_key = "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"

# Definir o modelo do ChatGPT
model_engine = "text-davinci-003"
#model_engine = "gpt-3.5-turbo"
model_prompt = ""

# Função que recebe a pergunta do usuário e retorna a resposta do ChatGPT
def get_answer(question):
    prompt = model_prompt + " " + question
    response = openai.Completion.create(
      engine=model_engine,
      prompt=prompt,
      temperature=0.5,
      max_tokens=1024,
      n=1,
      stop=None,
      timeout=10,
      top_p=1,
      frequency_penalty=0,
      presence_penalty=0.6,      
    )
    answer = response.choices[0].text.strip()
    return answer

def moderar_texto(texto):
    response = openai.Moderation.create(
        input=texto,
    )
    output = response["results"][0]
    return output

def solicitar_dados_compra():
    input("\n" + "🤖 BV IA Interact 🤖 " + "\n" + " Olá! Por gentileza, informe-nos qual o seu CPF, endereco "
                                                   "data de nascimento  para que possamos preencher o contrato." + "\n")

def solicitar_dados_cotacao():
    input("\n" + "🤖 BV IA Interact 🤖 " + "\n" + " Olá! Por gentileza, informe-nos qual o modelo, ano e placa do "
                                                   "veículo para que possamos fornecer uma cotação precisa." + "\n")

def gerar_contrato():
    #   x = random.randrange(1,5)
    print("\n \n" +"Com certeza, posso ajudá-lo. Abaixo segue algumas opções de contratação de seguro para o seu veículo, "
          "com opções de seguradoras e formas de pagamento." + "\n")

    print("################################## CONTRATO DE SEGURO AUTO BV ##################################, "
          + "\n" + "diversas opções de cobertura para veículos, como cobertura para colisão,roubo e furto "
          + "\n" + "incêndio, danos a terceiros, entre outras. Além disso, a Porto Seguro oferece diferentes "
          + "\n" + "incêndio, danos a terceiros, entre outras. Além disso, a Porto Seguro oferece diferentes "
          + "\n" + "incêndio, danos a terceiros, entre outras. Além disso, a Porto Seguro oferece diferentes "
          + "\n" + "incêndio, danos a terceiros, entre outras. Além disso, a Porto Seguro oferece diferentes "
          + "\n" + "incêndio, danos a terceiros, entre outras. Além disso, a Porto Seguro oferece diferentes "
          + "\n" + "incêndio, danos a terceiros, entre outras. Além disso, a Porto Seguro oferece diferentes "
          + "\n" + "incêndio, danos a terceiros, entre outras. Além disso, a Porto Seguro oferece diferentes "
          + "\n" + "incêndio, danos a terceiros, entre outras. Além disso, a Porto Seguro oferece diferentes "
          + "\n" + "incêndio, danos a terceiros, entre outras. Além disso, a Porto Seguro oferece diferentes "
          + "\n" + "incêndio, danos a terceiros, entre outras. Além disso, a Porto Seguro oferece diferentes "
          + "\n" + " SAO PAULO 13 DE MARCO DE 2023                                                           "
          + "\n" + " ASSINATURA  ________________________                                                    "
          + "\n" + "################################## CONTRATO DE SEGURO AUTO BV ##################################" + "\n")

def moderar_chat(texto):
    output = moderar_texto(texto)
    # Imprima a resposta
    if output["flagged"]:
        print("O texto contém linguagem inapropriada e deve ser moderado.")
        exit()

def gerar_cotacao():

    #   x = random.randrange(1,5)
    print("\n \n" +"Com certeza, posso ajudá-lo. Abaixo segue algumas opções de contratação de seguro para o seu veículo, "
          "com opções de seguradoras e formas de pagamento." + "\n")

    print("OPÇAO 1 [] - Porto Seguro: A Porto Seguro é uma das principais seguradoras do mercado e oferece, " \
          + "\n" + "diversas opções de cobertura para veículos, como cobertura para colisão,roubo e furto " \
          + "\n" + "incêndio, danos a terceiros, entre outras. Além disso, a Porto Seguro oferece diferentes " \
          + "\n" + "formas de pagamento, como parcelamento em até 10x sem juros no cartão de crédito." + "\n")

    print(
        "OPÇAO 2 [] - A Azul Seguros é uma seguradora especializada em seguros de automóveis e oferece diversas opções "
        + "\n" + "de cobertura, como cobertura para colisão, roubo e furto, incêndio, danos a terceiros, entre outras. "
        + "\n" + "A Azul Seguros também oferece diferentes formas de pagamento, como pagamento à vista com desconto, "
        + "\n" + "parcelamento em até 10x sem juros no cartão de crédito, entre outras opções." + "\n")

    print("OPÇAO 3 [] - A Allianz é uma das maiores seguradoras do mundo e oferece diversas opções de cobertura para "
          + "\n" + "veículos, como cobertura para colisão, roubo e furto, incêndio, danos a terceiros, entre outras. "
          + "\n" + "A Allianz também oferece diferentes formas de pagamento, como parcelamento em até 6x sem juros "
          + "\n" + "no cartão de crédito." + "\n")

    def get_chat_history_as_text(self, history, include_last_turn=True, approx_max_tokens=1000) -> str:
        history_text = ""
        for h in reversed(history if include_last_turn else history[:-1]):
            history_text = """<|im_start|>user""" +"\n" + h["user"] + "\n" + """<|im_end|>""" + "\n" + """<|im_start|>assistant""" + "\n" + (h.get("bot") + """<|im_end|>""" if h.get("bot") else "") + "\n" + history_text
            if len(history_text) > approx_max_tokens*4:
                break    
        return history_text

def nonewlines(s: str) -> str:
    return s.replace('\n', ' ').replace('\r', ' ')

def get_chat_history_as_text(self, history, include_last_turn=True, approx_max_tokens=1000) -> str:
    history_text = ""
    for h in reversed(history if include_last_turn else history[:-1]):
        history_text = """<|im_start|>user""" +"\n" + h["user"] + "\n" + """<|im_end|>""" + "\n" + """<|im_start|>assistant""" + "\n" + (h.get("bot") + """<|im_end|>""" if h.get("bot") else "") + "\n" + history_text
        if len(history_text) > approx_max_tokens*4:
            break    
    return history_text

class Approach:
    def run(self, q: str, use_summaries: bool) -> any:
        raise NotImplementedError

azure_credential = DefaultAzureCredential()

# Set up clients for Cognitive Search and Storage
search_client = SearchClient(
    endpoint=f"https://gptkb-2hyfr4d3p46b6.search.windows.net",
    index_name="myindex",
    credential=azure_credential)
blob_client = BlobServiceClient(
    account_url=f"https://st2hyfr4d3p46b6.blob.core.windows.net", 
    credential=azure_credential)
blob_container = blob_client.get_container_client("content")

content_field = "content"
KB_FIELDS_CATEGORY = "category"
sourcepage_field = "sourcepage"
history: list[dict]
history = [{"bot":"Olá tudo bem? Como posso te ajudar ?", "user":input("\n" + "🤖 BV IA Interact 🤖: Olá tudo bem? Como posso te ajudar ? " + "\n")}]
overrides: dict
overrides = {"semantic_ranker":True,"semantic_captions":False,"exclude_Category":"","top":3,"temperature":0.5,"promptTemplatePrefix":"","promptTemplateSuffix":"","suggest_followup_questions":True}

try:
    impl =  ChatReadRetrieveReadApproach(search_client, model_engine, model_engine, sourcepage_field, content_field)
    if not impl:
        print({"error": "unknown approach"})
    r = impl.run(history, overrides or {})
    print(r["answer"])
    history.append([{"bot":""},{"user":r}])
    
except Exception as e:
    logging.exception("Exception in /chat")
    print({"error": str(e)})




# Simple retrieve-then-read implementation, using the Cognitive Search and OpenAI APIs directly. It first retrieves
# top documents from search, then constructs a prompt with them, and then uses OpenAI to generate an completion 
# (answer) with that prompt.

prompt_prefix = """<|im_start|>system
Assitente auxilia os clientes de uma corretora de venda de seguros de auto a tirar dúvidas sobre planos de seguros . Seja breve em suas respostas.
Responda APENAS com os fatos listados na lista de fontes abaixo. Se não houver informações suficientes abaixo, diga que não sabe. Não gere respostas que não usem as fontes abaixo. Se fazer uma pergunta esclarecedora ao usuário ajudar, faça a pergunta.
Para obter informações tabulares, retorne-as como uma tabela html. Não retorne o formato de remarcação.
Cada fonte tem um nome seguido de dois pontos e as informações reais, sempre inclua o nome da fonte para cada fato que você usar na resposta. Use colchetes para referenciar a fonte, por exemplo [info1.txt]. Não combine fontes, liste cada fonte separadamente, por exemplo [info1.txt][info2.pdf].

{follow_up_questions_prompt}
{injected_prompt}
Sources:
{sources}
<|im_end|>
{chat_history}
"""

follow_up_questions_prompt_content = """Gere três breves perguntas de acompanhamento que o usuário provavelmente faria a seguir sobre seu plano de saúde e manual do funcionário.
    Use colchetes angulares duplos para fazer referência às perguntas, por exemplo <<Existem exclusões de prescrições?>>.
    Tente não repetir perguntas que já foram feitas.
    Gere apenas perguntas e não gere nenhum texto antes ou depois das perguntas, como 'Próximas perguntas''"""

query_prompt_template = """Segue abaixo um histórico da conversa até o momento, e uma nova pergunta feita pelo usuário que precisa ser respondida através de uma busca em uma base de conhecimento sobre planos de saúde do empregado e o manual do empregado.
    Gere uma consulta de pesquisa com base na conversa e na nova pergunta.
    Não inclua nomes de arquivos de origem citados e nomes de documentos, por exemplo, info.txt ou doc.pdf nos termos de consulta de pesquisa.
    Não inclua nenhum texto dentro de [] ou <<>> nos termos da consulta de pesquisa.
    Se a pergunta não estiver em inglês, traduza a pergunta para o inglês antes de gerar a consulta de pesquisa.

Chat History:
{chat_history}

Question:
{question}

Search query:
"""


# Set up clients for Cognitive Search and Storage
search_client = SearchClient(
    endpoint=f"https://gptkb-2hyfr4d3p46b6.search.windows.net",
    index_name="myindex",
    credential=azure_credential)
blob_client = BlobServiceClient(
    account_url=f"https://st2hyfr4d3p46b6.blob.core.windows.net", 
    credential=azure_credential)
blob_container = blob_client.get_container_client("content")

# Loop para receber perguntas do usuário e exibir as respostas do ChatGPT
#  while True:
#     question = input("Digite sua pergunta (ou 'sair' para encerrar): ")
#     if question.lower() == "sair":
#        break
#    answer = get_answer(question)
#     print(answer)


# question = "Você será um vendedor de seguros que irá atender a um cliente, sendo gentil e educado, tirando " \
#           "as dúvidas, e buscando a melhor maneira de ajuda-lo. caso você nao consiga pode direciona-lo para " \
#           "um atendimento humano no nosso call center.  "

# Loop para receber perguntas do usuário e exibir as respostas do ChatGPT


print("\n" + datetime.now().__str__() + "\n")

print("BBBBBBBBBBBBBBBBB   VVVVVVVV           VVVVVVVV     IIIIIIIIII               AAA")
print("B::::::::::::::::B  V::::::V           V::::::V     I::::::::I              A:::A")
print("B::::::BBBBBB:::::B V::::::V           V::::::V     I::::::::I             A:::::A")
print("BB:::::B     B:::::BV::::::V           V::::::V     II::::::II            A:::::::A")
print("  B::::B     B:::::B V:::::V           V:::::V        I::::I             A:::::::::A")
print(" B::::B     B:::::B  V:::::V         V:::::V         I::::I            A:::::A:::::A")
print(" B::::BBBBBB:::::B    V:::::V       V:::::V          I::::I           A:::::A A:::::A")
print("  B:::::::::::::BB      V:::::V     V:::::V           I::::I          A:::::A   A:::::A")
print("  B::::BBBBBB:::::B      V:::::V   V:::::V            I::::I         A:::::A     A:::::A")
print("  B::::B     B:::::B      V:::::V V:::::V             I::::I        A:::::AAAAAAAAA:::::A")
print("  B::::B     B:::::B       V:::::V:::::V              I::::I       A:::::::::::::::::::::A")
print("  B::::B     B:::::B        V:::::::::V               I::::I      A:::::AAAAAAAAAAAAA:::::A")
print("BB:::::BBBBBB::::::B         V:::::::V              II::::::II   A:::::A             A:::::A")
print("B:::::::::::::::::B           V:::::V               I::::::::I  A:::::A               A:::::A")
print("B::::::::::::::::B             V:::V                I::::::::I A:::::A                 A:::::A")
print("BBBBBBBBBBBBBBBBB               VVV                 IIIIIIIIIIAAAAAAA                   AAAAAAA")

#  """iniciar o chat cordial"""

content_field = "content"
KB_FIELDS_CATEGORY = "category"
sourcepage_field = "sourcepage"


pre_prompt = """ você é um Assitente que vai auxiliar os clientes de uma corretora de seguros de automóveis a tirar dúvidas sobre seus planos . Seja breve em suas respostas.
Responda APENAS com os fatos listados na lista de fontes abaixo. Se não houver informações suficientes abaixo, diga que não sabe. Não gere respostas que não usem as fontes abaixo. Se fazer uma pergunta esclarecedora ao usuário ajudar, faça a pergunta.
Cada Source tem um nome seguido de dois pontos e as informações reais, sempre inclua o nome da fonte para cada fato que você usar na resposta. Use colchetes para referenciar a fonte, por exemplo [info1.txt]. Não combine fontes, liste cada fonte separadamente, por exemplo [info1.txt][info2.pdf].

    {injected_prompt}
    Sources:
    {sources}
    <|im_end|>
"""

entrada = input("\n" + "🤖 BV IA Interact 🤖: Olá tudo bem? Como posso te ajudar ? " + "\n")
q=entrada
r= search_client.search(q, top=3)
results = [doc[sourcepage_field] + ": " + nonewlines(doc[content_field]) for doc in r]
content =  pre_prompt.format( injected_prompt=entrada, sources=results)
answer = get_answer(content)
chat_history =  entrada + answer

print("\n" + answer  + "\n")

while True:
    query_prompt_template = """Segue abaixo um histórico da conversa até o momento, e uma nova pergunta feita pelo usuário que precisa ser respondida através de uma busca em uma base de conhecimento seguros.
 
    histórico da conversa:
    {chat_history}

    Nova pergunta do usuário:
    {question}

    """
    entrada = input("\n" + "🤖 BV IA Interact 🤖: Resposta: " + "\n")
    prompt = query_prompt_template.format( chat_history=chat_history, question=entrada)

    q=entrada
    r= search_client.search(q, top=3)
    results = [doc[sourcepage_field] + ": " + nonewlines(doc[content_field]) for doc in r]
    content = " \n".join(results)
    answer = get_answer(content)
    chat_history +=  entrada + answer
    print("\n" + answer + "\n")
    
   

    # STEP 1: Generate an optimized keyword search query based on the chat history and the last question
    #prompt = input("Digital seu texto")
    #completion = openai.Completion.create(
    #    engine=self.gpt_deployment, 
    #    prompt=prompt, 
    #    temperature=0.0, 
    #    max_tokens=32, 
    #    n=1, 
    #    stop=["\n"])
    #q = completion.choices[0].text

    # STEP 2: Retrieve relevant documents from the search index with the GPT optimized query


   
    #r = search_client.search(q, 
    #                                filter=filter,
    #                                query_type=QueryType.SEMANTIC, 
    #                                query_language="en-us", 
    #                                query_speller="lexicon", 
    #                                semantic_configuration_name="default", 
    #                                top=3, 
    #                                query_caption="extractive|highlight-false" )
    #r = self.search_client.search(q, filter=filter, top=top)
    

    #use_semantic_captions:
    #results = [doc[sourcepage_field] + ": " + nonewlines(" . ".join([c.text for c in doc['@search.captions']])) for doc in r]




    # Allow client to replace the entire prompt, or to inject into the exiting prompt using >>>
    #prompt = prompt_prefix.format(injected_prompt="", sources=content, chat_history= get_chat_history_as_text(history), follow_up_questions_prompt=follow_up_questions_prompt)prompt_override = ">>>" #overrides.get("prompt_template")

    #if prompt_override is None:
    #    prompt = prompt_prefix.format(injected_prompt="", sources=content, chat_history= get_chat_history_as_text(history), follow_up_questions_prompt=follow_up_questions_prompt)
    #elif prompt_override.startswith(">>>"):
    #    prompt = prompt_prefix.format(injected_prompt=prompt_override[3:] + "\n", sources=content, chat_history=get_chat_history_as_text(history), follow_up_questions_prompt=follow_up_questions_prompt)
    #else:
    #    prompt = prompt_override.format(sources=content, chat_history= get_chat_history_as_text(history), follow_up_questions_prompt=follow_up_questions_prompt)

    # STEP 3: Generate a contextual and content specific answer using the search results and chat history
    #completion = openai.Completion.create(
    #    engine= chatgpt_deployment, 
    #    prompt=prompt, 
    #    temperature=overrides.get("temperature") or 0.7, 
    #    max_tokens=1024, 
    #    n=1, 
    #    stop=["<|im_end|>", "<|im_start|>"])


    


print("\n" + datetime.now().__str__() + "\n")


#intecoes_cotacao = ["cotação seguro", "cotar seguro", "informação seguro", "preço seguro"]
#intecoes_comprar = ["comprar seguro", "assinar contrato", "quero seguro", "comprar produtos", "quero fechar"]

#  """iniciar o chat cordial"""
# """ se tem a intecao de uma cotacao """
#    """ se tem a intecao de uma compra """
#    """Finalizar cordialmente """
#    """Em caso de timeot --> direcionar pra humano"""

#    """ Rodar a cada interacao """

#    """ Mascarar/criar persona PII """
#    """ Moderador -> Verificar se intencao de ofender  -> abortar """

#   """ Determinar a intecao """
#    """     essa msg tem a intencao de uma cotacao -> Chamar cotacao"""
#   """     essa msg tem a intencao de uma compra -> Chamar compra mode de pagamentos"""
#    """     essa msg tem a intencao de uma efetivar -> Sispag """

#  """    Classificar os sentimento em relacao ao atendimento """
# ola tudo bem?

# gostaria de cotar um seguro, consegue me ajudar ?


# def personas (realdata):

# Encontrar todas as informações PII no texto

# persona_list = []
# persona_list [] = "Olá! Gostaria de uma cotação para seguro de auto."
# name_persona=  "Ana"

# return personaText
# intencao = ChatBV.ChatGPT_Call.get_answer(
#    "Me ajude a descobrir na frase a seguir qual é a principal intenção do usuário é: cotar, "
#   "simular, avaliar, ver quanto custa, saber quanto custa um "
#   "seguro, responda apenas sim ou não. " + entrada)

# while True:
#   if entrada.lower() == "sair":
#         break

    # avaliar a intencao
#     moderar_chat(entrada)
#     intencao = get_answer("Qual é a principal intenção do usuário em duas palavras:" + entrada)


#   print("\nIntencao:" + intencao + "\n")

#     flag = False
#     for srtCotar in intecoes_cotacao:
#         if srtCotar == intencao.lower():
#             solicitar_dados_cotacao()
#             gerar_cotacao()
#             flag = True
#             entrada = input("\n" + "🤖 BV IA Interact 🤖: Voce Gostou do orcamento. vamos fechar ?" + "\n")
#             intencao=""
#     for srtComprar in intecoes_comprar:
#         if srtComprar == intencao.lower():
#            solicitar_dados_compra()
#             gerar_contrato()
#             flag = True
#             entrada = input("\n" + "🤖 BV IA Interact 🤖: Agora é assinar digitalmente e pronto, voce estara seguro" + "\n")
#             intencao = ""
#     if not flag:
#         resposta = get_answer(entrada)
#         moderar_chat(entrada)
#         entrada = input("\n" + "🤖 BV IA Interact 🤖:" + resposta + "\n")
