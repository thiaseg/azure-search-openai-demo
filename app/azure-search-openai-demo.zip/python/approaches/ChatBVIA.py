from datetime import datetime
import openai 
from azure.search.documents import SearchClient
from chatreadretrieveread import ChatReadRetrieveReadApproach
#from text import nonewlines
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient
import logging
#openai.api_key = "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"
openai.api_key ="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"

prompt_prefix = """<|im_start|>sistema
Assitente auxilia os clientes de uma corretora de seguros de auto a tirar dúvidas sobre planos de seguros. 
Seja breve em suas respostas.
Responda APENAS com os fatos listados nas fontes abaixo. Se não houver informações suficientes abaixo, diga 
que não sabe. Não gere respostas que não usem as fontes abaixo.Se fizer uma pergunta te ajude a elaborar uma resposta 
melhor,faça-a.Para informações tabulares, retorne-as como uma tabela html.Não retorne no formato markdown.
Cada fonte tem um nome seguido de dois pontos e as informações reais,sempre inclua o nome da fonte para cada fato que 
você usar na resposta. Use colchetes para referenciar a fonte,por exemplo [info1.txt]. Não combine fontes, liste cada 
fonte separadamente, por exemplo[info1.txt][info2.pdf].
{follow_up_questions_prompt}
{injected_prompt}
Fontes:
{sources}
<|im_end|>
{chat_history}
"""


# Definir o modelo do ChatGPT
model_engine = "text-davinci-003"
#model_engine = "gpt-3.5-turbo"
model_prompt = ""

def printaBV():
    print("\n" + datetime.now().__str__() + "\n")

    print("BBBBBBBBBBBBBBBBB   VVVVVVVV           VVVVVVVV     IIIIIIIIII               AAA")
    print("B::::::::::::::::B  V::::::V           V::::::V     I::::::::I              A:::A")
    print("B::::::BBBBBB:::::B V::::::V           V::::::V     I::::::::I             A:::::A")
    print("BB:::::B     B:::::BV::::::V           V::::::V     II::::::II            A:::::::A")
    print("  B::::B     B:::::B V:::::V           V:::::V        I::::I             A:::::::::A")
    print(" B::::B     B:::::B  V:::::V         V:::::V         I::::I            A:::::A:::::A")
    print(" B::::BBBBBB:::::B    V:::::V       V:::::V          I::::I           A:::::A A:::::A")
    print("  B:::::::::::::BB      V:::::V     V:::::V           I::::I          A:::::A   A:::::A")
    print("  B::::BBBBBB:::::B      V:::::V   V:::::V            I::::I         A:::::A     A:::::A")
    print("  B::::B     B:::::B      V:::::V V:::::V             I::::I        A:::::AAAAAAAAA:::::A")
    print("  B::::B     B:::::B       V:::::V:::::V              I::::I       A:::::::::::::::::::::A")
    print("  B::::B     B:::::B        V:::::::::V               I::::I      A:::::AAAAAAAAAAAAA:::::A")
    print("BB:::::BBBBBB::::::B         V:::::::V              II::::::II   A:::::A             A:::::A")
    print("B:::::::::::::::::B           V:::::V               I::::::::I  A:::::A               A:::::A")
    print("B::::::::::::::::B             V:::V                I::::::::I A:::::A                 A:::::A")
    print("BBBBBBBBBBBBBBBBB               VVV                 IIIIIIIIIIAAAAAAA                   AAAAAAA")

class Approach:
    def run(self, q: str, use_summaries: bool) -> any:
        raise NotImplementedError

printaBV()

azure_credential = DefaultAzureCredential()

# Set up clients for Cognitive Search and Storage
search_client = SearchClient(
    endpoint=f"https://gptkb-2hyfr4d3p46b6.search.windows.net",
    index_name="myindex",
    credential=azure_credential)
blob_client = BlobServiceClient(
    account_url=f"https://st2hyfr4d3p46b6.blob.core.windows.net", 
    credential=azure_credential)
blob_container = blob_client.get_container_client("content")

content_field = "content"
KB_FIELDS_CATEGORY = "category"
sourcepage_field = "sourcepage"
history: list[dict]
history = [{"bot":"Olá tudo bem? Como posso te ajudar ?", "user":input("\n" + "🤖 BV IA Interact 🤖: Olá tudo bem? Como posso te ajudar ? " + "\n")}]
overrides: dict
overrides = {"semantic_ranker":False,"semantic_captions":False,"exclude_Category":"","top":3,"temperature":0.7,"promptTemplatePrefix":"","promptTemplateSuffix":"","suggest_followup_questions":True}
impl =  ChatReadRetrieveReadApproach(search_client, model_engine, model_engine, sourcepage_field, content_field)
while True:
    try:        
        if not impl:
            print({"error": "unknown approach"})
        r = impl.run(history, overrides or {})
        print(r["answer"])
        history.append({"bot":r["answer"],"user": input("\n" + "🤖 BV IA Interact 🤖: Olá tudo bem? Como posso te ajudar ? " + "\n")})
       
    except Exception as e:
        logging.exception("Exception in /chat")
        print({"error": str(e)})








    